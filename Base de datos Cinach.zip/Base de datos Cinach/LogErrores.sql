USE Cinach;
GO

-- Crear la tabla para registrar las bitácoras de errores
CREATE TABLE LogErrores (
    id_error INT IDENTITY(1,1) PRIMARY KEY,
    ErrorNumber INT,
    ErrorSeverity INT,
    ErrorState INT,
    ErrorProcedure NVARCHAR(128),
    ErrorLine INT,
    ErrorMessage NVARCHAR(4000),
    FechaError DATETIME DEFAULT GETDATE()
);
GO