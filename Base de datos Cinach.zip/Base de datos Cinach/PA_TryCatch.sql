USE Cinach;
GO

-- PROCESAR COMPRA CON TARJETA (Con Try-Catch y Transacción)

CREATE OR ALTER PROCEDURE sp_ProcesarCompraConTarjeta
    @correo_contacto NVARCHAR(60),
    @id_usuario INT,
    @id_cartelera INT,
    @id_forma_pago INT,
    @id_promocion INT = NULL,
    @total_pagado DECIMAL(8,2),
    @numero_tarjeta NVARCHAR(20),
    @titular_tarjeta NVARCHAR(100),
    @id_asiento INT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        DECLARE @id_ticket INT;
        DECLARE @folio NVARCHAR(12);
        DECLARE @auth_code NVARCHAR(20);

        -- Generar folio y código de autorización
        SET @folio = 'CINA-' + UPPER(SUBSTRING(REPLACE(CAST(NEWID() AS NVARCHAR(50)), '-', ''), 1, 6));
        SET @auth_code = 'AUTH-' + FLOOR(RAND() * 899999 + 100000);

        -- Insertar el ticket de compra
        INSERT INTO generador_de_ticket (
            folio_alfanumerico, correo_contacto, total_pagado, 
            id_usuario, id_cartelera, id_forma_pago, id_promocion
        )
        VALUES (
            @folio, @correo_contacto, @total_pagado, 
            @id_usuario, @id_cartelera, @id_forma_pago, @id_promocion
        );

        SET @id_ticket = SCOPE_IDENTITY();

        -- Asociar el asiento
        INSERT INTO detalle_ticket_asientos (id_ticket, id_asiento)
        VALUES (@id_ticket, @id_asiento);

        -- Registrar la transacción de tarjeta
        INSERT INTO transacciones_tarjeta (
            id_ticket, numero_tarjeta_enmascarado, titular_tarjeta, 
            codigo_autorizacion, estado_pago
        )
        VALUES (
            @id_ticket, @numero_tarjeta, @titular_tarjeta, 
            @auth_code, 'APROBADO'
        );

        COMMIT TRANSACTION;
        
        SELECT @folio AS FolioGenerado, @auth_code AS CodigoAutorizacion, 'Compra exitosa' AS Mensaje;

    END TRY
    BEGIN CATCH
        -- Si ocurre un error, revertimos la transacción
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        -- Mostrar los detalles del error
        SELECT 
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_SEVERITY() AS ErrorSeverity,
            ERROR_STATE() AS ErrorState,
            ERROR_PROCEDURE() AS ErrorProcedure,
            ERROR_LINE() AS ErrorLine,
            ERROR_MESSAGE() AS ErrorMessage;
    END CATCH
END;
GO


-- CONSULTAR CARTELERA POR CINE (Con Try-Catch)

CREATE OR ALTER PROCEDURE sp_ConsultarCarteleraPorCine
    @id_cine INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        SELECT 
            c.id_cartelera,
            p.titulo AS Pelicula,
            p.clasificacion,
            p.duracion_minutos,
            s.numero_sala,
            f.fecha_proyeccion,
            h.hora_inicio,
            pb.precio_base
        FROM cartelera c
        INNER JOIN peliculas p ON c.id_pelicula = p.id_pelicula
        INNER JOIN numero_de_salas s ON c.id_sala = s.id_sala
        INNER JOIN fechas f ON c.id_fecha = f.id_fecha
        INNER JOIN horarios_de_peliculas h ON c.id_horario = h.id_horario
        INNER JOIN precios_de_boleto pb ON c.id_precio = pb.id_precio
        WHERE s.id_cine = @id_cine AND f.fecha_proyeccion >= CAST(GETDATE() AS DATE)
        ORDER BY f.fecha_proyeccion, h.hora_inicio;
    END TRY
    BEGIN CATCH
        SELECT 
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_SEVERITY() AS ErrorSeverity,
            ERROR_STATE() AS ErrorState,
            ERROR_PROCEDURE() AS ErrorProcedure,
            ERROR_LINE() AS ErrorLine,
            ERROR_MESSAGE() AS ErrorMessage;
    END CATCH
END;
GO


-- REPORTE DE VENTAS POR PELÍCULA (Con Try-Catch)

CREATE OR ALTER PROCEDURE sp_ReporteVentasPorPelicula
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        SELECT 
            p.titulo AS Pelicula,
            COUNT(gt.id_ticket) AS Total_Boletos_Vendidos,
            ISNULL(SUM(gt.total_pagado), 0.00) AS Ingresos_Totales
        FROM peliculas p
        LEFT JOIN cartelera c ON p.id_pelicula = c.id_pelicula
        LEFT JOIN generador_de_ticket gt ON c.id_cartelera = gt.id_cartelera
        GROUP BY p.id_pelicula, p.titulo
        ORDER BY Ingresos_Totales DESC;
    END TRY
    BEGIN CATCH
        SELECT 
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_SEVERITY() AS ErrorSeverity,
            ERROR_STATE() AS ErrorState,
            ERROR_PROCEDURE() AS ErrorProcedure,
            ERROR_LINE() AS ErrorLine,
            ERROR_MESSAGE() AS ErrorMessage;
    END CATCH
END;
GO


-- CANCELAR TICKET Y LIBERAR ASIENTOS (Con Try-Catch)

CREATE OR ALTER PROCEDURE sp_CancelarTicket
    @folio_alfanumerico NVARCHAR(12)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;
        
        DECLARE @id_ticket INT;

        SELECT @id_ticket = id_ticket 
        FROM generador_de_ticket 
        WHERE folio_alfanumerico = @folio_alfanumerico;

        IF @id_ticket IS NULL
        BEGIN
            RAISERROR('El folio especificado no existe en el sistema.', 16, 1);
        END

        -- Eliminar asientos apartados
        DELETE FROM detalle_ticket_asientos WHERE id_ticket = @id_ticket;

        -- Actualizar estatus del pago
        UPDATE transacciones_tarjeta 
        SET estado_pago = 'CANCELADO' 
        WHERE id_ticket = @id_ticket;

        COMMIT TRANSACTION;
        SELECT 'El ticket ha sido cancelado correctamente.' AS Resultado;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SELECT 
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_SEVERITY() AS ErrorSeverity,
            ERROR_STATE() AS ErrorState,
            ERROR_PROCEDURE() AS ErrorProcedure,
            ERROR_LINE() AS ErrorLine,
            ERROR_MESSAGE() AS ErrorMessage;
    END CATCH
END;
GO