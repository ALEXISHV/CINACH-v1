USE Cinach;
GO

-- 1. Eliminar la columna de la tabla usuarios
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('usuarios') AND name = 'matricula_o_empleado')
BEGIN
    ALTER TABLE usuarios DROP COLUMN matricula_o_empleado;
    PRINT 'Columna matricula_o_empleado eliminada de la tabla usuarios.';
END
GO

-- 2. Eliminar la columna de la tabla generador_de_ticket
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('generador_de_ticket') AND name = 'matricula_unach')
BEGIN
    ALTER TABLE generador_de_ticket DROP COLUMN matricula_unach;
    PRINT 'Columna matricula_unach eliminada de la tabla generador_de_ticket.';
END
GO

-------------------------------------------------------------------------------------

USE Cinach;
GO

CREATE OR ALTER PROCEDURE sp_RegistrarUsuario
    @nombre NVARCHAR(100),
    @correo NVARCHAR(100),
    @contrasena NVARCHAR(255),
    @rol NVARCHAR(20) = 'estudiante'
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Validar si el correo ya existe
    IF EXISTS (SELECT 1 FROM usuarios WHERE correo = @correo)
    BEGIN
        RAISERROR('El correo electrónico ya se encuentra registrado.', 16, 1);
        RETURN;
    END

    -- Insertar el nuevo usuario
    INSERT INTO usuarios (nombre, correo, contrasena, rol)
    VALUES (@nombre, @correo, @contrasena, @rol);
    
    SELECT SCOPE_IDENTITY() AS id_usuario_creado;
END;
GO

-- ==========================================================
-- 2. SP: CONSULTAR CARTELERA POR CINE
-- Cruza múltiples tablas para filtrar funciones vigentes por sucursal.
-- ==========================================================
CREATE OR ALTER PROCEDURE sp_ConsultarCarteleraPorCine
    @id_cine INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        c.id_cartelera,
        p.titulo AS Pelicula,
        p.clasificacion,
        p.duracion_minutos,
        s.numero_sala,
        f.fecha_proyeccion,
        h.hora_inicio,
        pb.precio_base
    FROM cartelera c
    INNER JOIN peliculas p ON c.id_pelicula = p.id_pelicula
    INNER JOIN numero_de_salas s ON c.id_sala = s.id_sala
    INNER JOIN fechas f ON c.id_fecha = f.id_fecha
    INNER JOIN horarios_de_peliculas h ON c.id_horario = h.id_horario
    INNER JOIN precios_de_boleto pb ON c.id_precio = pb.id_precio
    WHERE s.id_cine = @id_cine AND f.fecha_proyeccion >= CAST(GETDATE() AS DATE)
    ORDER BY f.fecha_proyeccion, h.hora_inicio;
END;
GO

-- ==========================================================
-- 3. SP: REPORTE DE VENTAS POR PELÍCULA
-- Agrega y calcula ingresos totales y boletos vendidos por cada película.
-- ==========================================================
CREATE OR ALTER PROCEDURE sp_ReporteVentasPorPelicula
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        p.titulo AS Pelicula,
        COUNT(gt.id_ticket) AS Total_Boletos_Vendidos,
        ISNULL(SUM(gt.total_pagado), 0.00) AS Ingresos_Totales
    FROM peliculas p
    LEFT JOIN cartelera c ON p.id_pelicula = c.id_pelicula
    LEFT JOIN generador_de_ticket gt ON c.id_cartelera = gt.id_cartelera
    GROUP BY p.id_pelicula, p.titulo
    ORDER BY Ingresos_Totales DESC;
END;
GO

-- ==========================================================
-- 4. SP: CANCELAR TICKET Y LIBERAR ASIENTOS
-- Revierte la compra, elimina el detalle y marca la tarjeta como cancelada.
-- ==========================================================
CREATE OR ALTER PROCEDURE sp_CancelarTicket
    @folio_alfanumerico NVARCHAR(12)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    
    BEGIN TRY
        DECLARE @id_ticket INT;

        SELECT @id_ticket = id_ticket 
        FROM generador_de_ticket 
        WHERE folio_alfanumerico = @folio_alfanumerico;

        IF @id_ticket IS NULL
        BEGIN
            RAISERROR('El folio especificado no existe en el sistema.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Eliminar asientos apartados
        DELETE FROM detalle_ticket_asientos WHERE id_ticket = @id_ticket;

        -- Actualizar estatus del pago
        UPDATE transacciones_tarjeta 
        SET estado_pago = 'CANCELADO' 
        WHERE id_ticket = @id_ticket;

        COMMIT TRANSACTION;
        SELECT 'El ticket ha sido cancelado correctamente.' AS Resultado;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO