USE Cinach;
GO

-- 1. CREACIÓN DEL USUARIO PARA LA APLICACIÓN WEB

CREATE LOGIN WebCinachLogin WITH PASSWORD = 'PasswordSeguro123!';
GO

CREATE USER usuario_web FOR LOGIN WebCinachLogin;
GO

ALTER ROLE db_datareader ADD MEMBER usuario_web;
ALTER ROLE db_datawriter ADD MEMBER usuario_web;
GO

GRANT EXECUTE ON sp_ProcesarCompraConTarjeta TO usuario_web;
GRANT SELECT ON v_DetalleTicketParaCorreo TO usuario_web;
GO

-- 2. CREACIÓN DEL USUARIO ADMINISTRADOR

CREATE LOGIN AdminCinachLogin WITH PASSWORD = 'AdminPassword2026!';
GO

CREATE USER usuario_admin FOR LOGIN AdminCinachLogin;
GO

ALTER ROLE db_owner ADD MEMBER usuario_admin;
GO
