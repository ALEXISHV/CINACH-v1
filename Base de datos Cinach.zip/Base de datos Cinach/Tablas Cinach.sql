-- Creación de Tablas
CREATE TABLE Usuarios (
    id_usuario INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL, -- validar que sea correo institucional (@unach.mx)
    contrasena VARCHAR(255) NOT NULL,
    rol VARCHAR(20) CHECK (rol IN ('estudiante', 'docente', 'admin')) DEFAULT 'estudiante',
    matricula_o_empleado VARCHAR(50) UNIQUE -- para distinguir si es alumno o profe
);

CREATE TABLE categoria_de_peliculas (
    id_categoria INT IDENTITY(1,1) PRIMARY KEY,
    nombre_categoria NVARCHAR(30) NOT NULL,
    descripcion NVARCHAR(100)
);

CREATE TABLE peliculas (
    id_pelicula INT IDENTITY(1,1) PRIMARY KEY,
    titulo NVARCHAR(100) NOT NULL,
    sinopsis NVARCHAR(MAX),
    duracion_minutos INT NOT NULL,
    clasificacion NVARCHAR(10) NOT NULL,
    poster_url NVARCHAR(200),
    id_categoria INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES categoria_de_peliculas(id_categoria)
);

CREATE TABLE eleccion_de_cines (
    id_cine INT IDENTITY(1,1) PRIMARY KEY,
    nombre_cine NVARCHAR(50) NOT NULL,
    direccion NVARCHAR(100) NOT NULL,
    ciudad NVARCHAR(30) NOT NULL
);

CREATE TABLE numero_de_salas (
    id_sala INT IDENTITY(1,1) PRIMARY KEY,
    numero_sala NVARCHAR(15) NOT NULL,
    capacidad_asientos INT NOT NULL,
    id_cine INT NOT NULL,
    FOREIGN KEY (id_cine) REFERENCES eleccion_de_cines(id_cine)
);

CREATE TABLE numero_de_asientos (
    id_asiento INT IDENTITY(1,1) PRIMARY KEY,
    numero_asiento NVARCHAR(5) NOT NULL,
    fila NVARCHAR(3) NOT NULL,
    id_sala INT NOT NULL,
    FOREIGN KEY (id_sala) REFERENCES numero_de_salas(id_sala)
);

CREATE TABLE fechas (
    id_fecha INT IDENTITY(1,1) PRIMARY KEY,
    fecha_proyeccion DATE NOT NULL,
    dia_semana NVARCHAR(15) NOT NULL
);

CREATE TABLE horarios_de_peliculas (
    id_horario INT IDENTITY(1,1) PRIMARY KEY,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL
);

CREATE TABLE precios_de_boleto (
    id_precio INT IDENTITY(1,1) PRIMARY KEY,
    tipo_boleto NVARCHAR(30) NOT NULL,
    precio_base DECIMAL(8,2) NOT NULL
);

CREATE TABLE promociones (
    id_promocion INT IDENTITY(1,1) PRIMARY KEY,
    nombre_promocion NVARCHAR(50) NOT NULL,
    porcentaje_descuento DECIMAL(5,2) DEFAULT 0.00,
    aplica_estudiante_unach BIT DEFAULT 0
);

CREATE TABLE forma_de_pago (
    id_forma_pago INT IDENTITY(1,1) PRIMARY KEY,
    metodo NVARCHAR(30) NOT NULL
);

INSERT INTO forma_de_pago (metodo) 
VALUES ('Tarjeta de Débito'), ('Tarjeta de Crédito');


CREATE TABLE cartelera (
    id_cartelera INT IDENTITY(1,1) PRIMARY KEY,
    id_fecha INT NOT NULL,
    id_pelicula INT NOT NULL,
    id_horario INT NOT NULL,
    id_sala INT NOT NULL,
    id_precio INT NOT NULL,
    FOREIGN KEY (id_fecha) REFERENCES fechas(id_fecha),
    FOREIGN KEY (id_pelicula) REFERENCES peliculas(id_pelicula),
    FOREIGN KEY (id_horario) REFERENCES horarios_de_peliculas(id_horario),
    FOREIGN KEY (id_sala) REFERENCES numero_de_salas(id_sala),
    FOREIGN KEY (id_precio) REFERENCES precios_de_boleto(id_precio)
);

GO
-- Vista para extraer la información detallada para el correo electrónico
CREATE VIEW v_DetalleTicketParaCorreo AS
SELECT 
    t.id_ticket,
    t.folio_alfanumerico,
    t.correo_contacto,
    t.matricula_unach,
    t.total_pagado,
    p.titulo AS pelicula,
    p.poster_url,
    c.nombre_cine,
    c.direccion AS direccion_cine,
    s.numero_sala,
    f.fecha_proyeccion,
    h.hora_inicio,
    STRING_AGG(CONCAT(a.fila, a.numero_asiento), ', ') AS asientos_reservados,
    tt.codigo_autorizacion,
    tt.numero_tarjeta_enmascarado
FROM generador_de_ticket t
INNER JOIN cartelera car ON t.id_cartelera = car.id_cartelera
INNER JOIN peliculas p ON car.id_pelicula = p.id_pelicula
INNER JOIN numero_de_salas s ON car.id_sala = s.id_sala
INNER JOIN eleccion_de_cines c ON s.id_cine = c.id_cine
INNER JOIN fechas f ON car.id_fecha = f.id_fecha
INNER JOIN horarios_de_peliculas h ON car.id_horario = h.id_horario
INNER JOIN detalle_ticket_asientos dta ON t.id_ticket = dta.id_ticket
INNER JOIN numero_de_asientos a ON dta.id_asiento = a.id_asiento
LEFT JOIN transacciones_tarjeta tt ON t.id_ticket = tt.id_ticket
GROUP BY 
    t.id_ticket, t.folio_alfanumerico, t.correo_contacto, t.matricula_unach, 
    t.total_pagado, p.titulo, p.poster_url, c.nombre_cine, c.direccion, 
    s.numero_sala, f.fecha_proyeccion, h.hora_inicio, tt.codigo_autorizacion,
    tt.numero_tarjeta_enmascarado;


    -- Procedimiento Almacenado
    GO
    CREATE PROCEDURE sp_ProcesarCompraConTarjeta
    @id_usuario INT,
    @correo_contacto NVARCHAR(60),
    @matricula_unach NVARCHAR(15),
    @id_cartelera INT,
    @id_forma_pago INT,
    @id_promocion INT = NULL,
    @total_pagado DECIMAL(8,2),
    @tarjeta_enmascarada NVARCHAR(20),
    @titular NVARCHAR(100),
    @lista_asientos NVARCHAR(MAX) -- ID asientos separados por coma
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Genera folio alfanumérico único (Ej: CINA-A892F)
        DECLARE @folio NVARCHAR(12);
        SET @folio = 'CINA-' + UPPER(SUBSTRING(CONVERT(VARCHAR(36), NEWID()), 1, 6));

        -- Inserta el Ticket
        INSERT INTO generador_de_ticket (
            folio_alfanumerico, correo_contacto, matricula_unach, 
            fecha_emision, total_pagado, id_usuario, 
            id_cartelera, id_forma_pago, id_promocion
        )
        VALUES (
            @folio, @correo_contacto, @matricula_unach, 
            GETDATE(), @total_pagado, @id_usuario, 
            @id_cartelera, @id_forma_pago, @id_promocion
        );

        DECLARE @nuevo_id_ticket INT = SCOPE_IDENTITY();

        -- Registra la simulación de Pago con Tarjeta
        DECLARE @codigo_auth NVARCHAR(20) = 'AUTH-' + CAST(FLOOR(RAND() * (900000) + 100000) AS NVARCHAR(6));
        
        INSERT INTO transacciones_tarjeta (id_ticket, numero_tarjeta_enmascarado, titular_tarjeta, codigo_autorizacion)
        VALUES (@nuevo_id_ticket, @tarjeta_enmascarada, @titular, @codigo_auth);

        -- Asocia los Asientos Seleccionados
        
        COMMIT TRANSACTION;

        -- Retorna el folio y el ID para la confirmación en la Web y el envío del correo
        SELECT 
            @nuevo_id_ticket AS id_ticket, 
            @folio AS folio_alfanumerico, 
            @codigo_auth AS codigo_autorizacion,
            'Pago Exitoso' AS mensaje;

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

