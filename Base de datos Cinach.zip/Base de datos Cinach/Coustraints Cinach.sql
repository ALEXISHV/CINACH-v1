USE Cinach;
GO

-- ==========================================================
-- 1. CONSTRAINT DE CORREO ÚNICO EN USUARIOS
-- Asegura que no se repita el correo institucional.
-- ==========================================================
ALTER TABLE usuarios
ADD CONSTRAINT UQ_Usuarios_Correo UNIQUE (correo);
GO

-- ==========================================================
-- 2. CONSTRAINT DE VALORES VÁLIDOS EN ROLES
-- Restringe los roles permitidos en el sistema.
-- ==========================================================
ALTER TABLE usuarios
ADD CONSTRAINT CK_Usuarios_Rol 
CHECK (rol IN ('estudiante', 'docente', 'admin'));
GO

-- ==========================================================
-- 3. CONSTRAINT DE PRECIOS POSITIVOS
-- Evita que se registren precios base negativos o de cero.
-- ==========================================================
ALTER TABLE precios_de_boleto
ADD CONSTRAINT CK_Precios_Base 
CHECK (precio_base > 0);
GO

-- ==========================================================
-- 4. CONSTRAINT DE CAPACIDAD DE SALAS
-- Asegura que una sala siempre tenga una capacidad mayor a 0 butacas.
-- ==========================================================
ALTER TABLE numero_de_salas
ADD CONSTRAINT CK_Salas_Capacidad 
CHECK (capacidad_asientos > 0);
GO

-- ==========================================================
-- 5. CONSTRAINT DE ESTADO DE PAGO VÁLIDO
-- Restringe los estatus posibles en las transacciones de tarjeta.
-- ==========================================================
ALTER TABLE transacciones_tarjeta
ADD CONSTRAINT CK_Transacciones_Estado 
CHECK (estado_pago IN ('APROBADO', 'RECHAZADO', 'CANCELADO'));
GO